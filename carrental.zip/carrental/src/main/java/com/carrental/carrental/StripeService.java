package com.carrental.carrental;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

@Service
public class StripeService {

    @PostConstruct
    public void init() {
        // Write your Stripe Secret Key here
        Stripe.apiKey = "sk_test_51RRiNZPEJ5lJGUJMWD66YdkntG2vAqzKvAgejwvH94kvsYdx0b1oggISW1SivluEb7k9mN5ZVT9j824jliWc8jJQ00wb66JVke";
    }

    public PaymentIntent createPaymentIntent(long amount, String currency) throws StripeException {
        PaymentIntentCreateParams params = PaymentIntentCreateParams.builder()
                .setAmount(amount) // Smallest currency unit, e.g. 1500 = 15.00 PLN
                .setCurrency(currency) // Lowercase currency code like "pln", "usd"
                .addPaymentMethodType("card")
                .build();

        return PaymentIntent.create(params);
    }
}
