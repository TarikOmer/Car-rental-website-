package com.carrental.carrental;

import com.carrental.carrental.CurrencyService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CurrencyController {

    private final CurrencyService currencyService;

    public CurrencyController(CurrencyService currencyService) {
        this.currencyService = currencyService;
    }

    @GetMapping("/api/currency/usd-pln")
    public Double getUsdPlnRate() {
        return currencyService.getUsdToPlnRate();
    }
}