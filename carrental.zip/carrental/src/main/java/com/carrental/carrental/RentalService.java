package com.carrental.carrental;

import com.carrental.carrental.Rental;
import com.carrental.carrental.RentalRepository;
import com.carrental.carrental.CarRepository;
import com.carrental.carrental.Car;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.temporal.ChronoUnit;
import java.time.LocalDate;
import java.util.List;

@Service
public class RentalService {

    @Autowired
    private RentalRepository rentalRepository;

    @Autowired
    private CarRepository carRepository;

    public Rental createRental(Rental rental) {
        Car car = carRepository.findById(rental.getCarId())
                .orElseThrow(() -> new RuntimeException("Car not found"));

        LocalDate start = rental.getStartDate();
        LocalDate end = rental.getEndDate();

        long days = ChronoUnit.DAYS.between(start, end);
        if (days <= 0) {
            throw new IllegalArgumentException("End date cannot be before the start date.");
        }

        double totalPrice = car.getPrice() * days;
        rental.setPrice(totalPrice);

        rental.setStatus("CONFIRMED");
        return rentalRepository.save(rental);
    }

    public List<Rental> getRentalsByUserId(String userId) {
        return rentalRepository.findByUserId(userId);
    }
    public Rental confirmRentalPayment(String rentalId, String paymentId) {
        Rental rental = rentalRepository.findById(rentalId)
                .orElseThrow(() -> new RuntimeException("Rental not found"));
        rental.setPaymentId(paymentId);
        rental.setStatus("CONFIRMED");
        return rentalRepository.save(rental);
    }
    public boolean deleteRental(String rentalId) {
        if (!rentalRepository.existsById(rentalId)) {
            return false;
        }
        rentalRepository.deleteById(rentalId);
        return true;
    }
    public List<Rental> getAllRentals() {
        return rentalRepository.findAll();
    }

}
