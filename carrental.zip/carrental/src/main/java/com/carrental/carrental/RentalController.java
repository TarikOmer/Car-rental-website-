package com.carrental.carrental;

import java.util.Map;
import java.util.List;
import com.carrental.carrental.Rental;
import com.carrental.carrental.RentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.Map;

@RestController
@RequestMapping("/api/rentals")
public class RentalController {



    @Autowired
    private RentalService rentalService;

    // If you want to get the user with Principal, use only this method
    @PostMapping("/create")
    public ResponseEntity<Rental> createRental(@RequestBody Rental rental, Principal principal) {
        String username = principal.getName();
        // TODO: Find the User object from username and set userId
        // Example:
        // User user = userRepository.findByUsername(username).orElseThrow(...);
        // rental.setUserId(user.getId());

        Rental createdRental = rentalService.createRental(rental);
        return ResponseEntity.ok(createdRental);
    }

    // If User ID is sent from frontend, use only this method
    /*
    @PostMapping("/create")
    public ResponseEntity<Rental> createRental(@RequestBody Rental rental) {
        Rental createdRental = rentalService.createRental(rental);
        return ResponseEntity.ok(createdRental);
    }
    */

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Rental>> getUserRentals(@PathVariable String userId) {
        List<Rental> rentals = rentalService.getRentalsByUserId(userId);
        return ResponseEntity.ok(rentals);
    }
    @PostMapping("/confirm-payment")
    public ResponseEntity<Rental> confirmPayment(@RequestBody Map<String, String> payload, Principal principal) {
        String rentalId = payload.get("rentalId");
        String paymentId = payload.get("paymentId");

        // Optionally, user authentication can be done with principal.getName()

        Rental updatedRental = rentalService.confirmRentalPayment(rentalId, paymentId);
        return ResponseEntity.ok(updatedRental);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRental(@PathVariable String id, Principal principal) {
        // Optionally, user authentication can be done with principal.getName()

        boolean deleted = rentalService.deleteRental(id);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }


}
