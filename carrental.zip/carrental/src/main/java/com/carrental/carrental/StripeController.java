package com.carrental.carrental;

import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.carrental.carrental.StripeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/stripe")
public class StripeController {

    @Autowired
    private StripeService stripeService;

    @PostMapping("/create-payment-intent")
    public ResponseEntity<Map<String, String>> createPaymentIntent(@RequestBody Map<String, Object> data) {
        try {
            long amount = Long.parseLong(data.get("amount").toString());
            String currency = data.get("currency").toString();

            PaymentIntent paymentIntent = stripeService.createPaymentIntent(amount, currency);

            return ResponseEntity.ok(Map.of("clientSecret", paymentIntent.getClientSecret()));

        } catch (StripeException e) {
            return ResponseEntity.status(500).body(Map.of("error", e.getMessage()));
        }
    }
}
