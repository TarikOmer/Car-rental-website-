package com.carrental.carrental;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class CurrencyService {

    private final RestTemplate restTemplate;

    private final String API_KEY = "cur_live_n9HuW93EfYUXIOMHjA4GYnm3IpAI0SOsxKuPlErL";

    @Autowired
    public CurrencyService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Double getUsdToPlnRate() {
        String url = "https://api.currencyapi.com/v3/latest?apikey=" + API_KEY + "&base_currency=USD&currencies=PLN";

        try {
            Map response = restTemplate.getForObject(url, Map.class);
            if (response != null && response.containsKey("data")) {
                Map data = (Map) response.get("data");
                if (data.containsKey("PLN")) {
                    Map plnData = (Map) data.get("PLN");
                    Object value = plnData.get("value");
                    if (value instanceof Number) {
                        return ((Number) value).doubleValue();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
