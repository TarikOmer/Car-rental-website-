package com.carrental.carrental;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/users")
@PreAuthorize("hasRole('ADMIN')")
public class AdminUserController {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;


    @GetMapping
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    @PostMapping
    public ResponseEntity<?> createUser(@RequestBody Map<String, String> userMap) {
        String username = userMap.get("username");
        String password = userMap.get("password");
        String role = userMap.get("role");

        if (username == null || password == null || role == null) {
            return ResponseEntity.badRequest().body("Missing user information");
        }

        if(userRepository.findByUsername(username).isPresent()) {
            return ResponseEntity.badRequest().body("This username already exists");
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(password));
        user.setRole(role.toUpperCase());

        userRepository.save(user);
        return ResponseEntity.ok("User successfully created");
    }


    @PutMapping("/{id}")
    public ResponseEntity<?> updateUserRole(@PathVariable String id, @RequestBody Map<String, String> updateMap) {
        String role = updateMap.get("role");
        if(role == null) {
            return ResponseEntity.badRequest().body("Role information is missing");
        }

        User user = userRepository.findById(id).orElse(null);
        if(user == null) {
            return ResponseEntity.notFound().build();
        }

        user.setRole(role.toUpperCase());
        userRepository.save(user);

        return ResponseEntity.ok("User role updated");
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable String id) {
        if (!userRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        userRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
