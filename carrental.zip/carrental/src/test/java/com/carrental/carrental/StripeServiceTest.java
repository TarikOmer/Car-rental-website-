package com.carrental.carrental;

import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class StripeServiceTest {

    private StripeService stripeService;

    @BeforeEach
    public void setup() {
        stripeService = Mockito.spy(new StripeService());
    }

    @Test
    public void integrationTestCreatePaymentIntent() throws Exception {
        StripeService service = new StripeService();
        service.init();

        PaymentIntent paymentIntent = service.createPaymentIntent(1500L, "pln");

        assertNotNull(paymentIntent);
        assertEquals(1500L, paymentIntent.getAmount());
        assertEquals("pln", paymentIntent.getCurrency());
        assertNotNull(paymentIntent.getClientSecret());

        System.out.println("Client Secret: " + paymentIntent.getClientSecret());
    }

}
