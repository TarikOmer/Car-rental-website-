package com.carrental.carrental;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class RentalServiceTest {

    @Mock
    private RentalRepository rentalRepository;

    @Mock
    private CarRepository carRepository;

    @InjectMocks
    private RentalService rentalService;

    public RentalServiceTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateRental_CorrectPriceCalculation() {

        Car car = new Car();
        car.setId("car123");
        car.setPrice(100.0);


        when(carRepository.findById("car123")).thenReturn(Optional.of(car));
        when(rentalRepository.save(any(Rental.class))).thenAnswer(invocation -> invocation.getArgument(0));


        Rental rental = new Rental();
        rental.setCarId("car123");
        rental.setStartDate(LocalDate.of(2025, 1, 1));
        rental.setEndDate(LocalDate.of(2025, 1, 6)); // 5 days

        Rental result = rentalService.createRental(rental);

        assertEquals(500.0, result.getPrice(), 0.001, "Total price should be 5 days * 100");
        assertEquals("CONFIRMED", result.getStatus());
        verify(rentalRepository).save(rental);
    }
}
